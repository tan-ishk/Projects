# ✈ BookMyFlight — Assignment 4

A full-stack flight booking web application built with **Spring Boot**, **React**, and **H2 (in-memory database)**.

---

## 🏗 Tech Stack

| Layer     | Technology                              |
|-----------|-----------------------------------------|
| Backend   | Spring Boot 3.2, Spring Data JPA, H2    |
| Frontend  | React 18, React Router v6, Axios        |
| Database  | H2 (in-memory, auto-seeded on startup)  |
| Build     | Maven (backend), npm (frontend)         |

---

## 🚀 Running the Application

### Backend (Spring Boot)

```bash
cd backend
mvn spring-boot:run
```

- Starts on **http://localhost:8080**
- H2 Console: **http://localhost:8080/h2-console**
  - JDBC URL: `jdbc:h2:mem:bookmyflight`
  - Username: `sa`, Password: _(empty)_
- Seeds 5 sample deals automatically on startup

### Frontend (React)

```bash
cd frontend
npm install
npm start
```

- Starts on **http://localhost:3000**
- Proxies API calls to `localhost:8080`

---

## 📋 Features

| Feature                                 | Details                                               |
|-----------------------------------------|-------------------------------------------------------|
| **Live deals on home page**             | Dynamically fetched; auto-refreshes every 30 seconds  |
| **Time-limited deals**                  | Each deal has a `validUntil` timestamp; auto-expires  |
| **Book using phone number**             | No username/password required                         |
| **My Bookings lookup**                  | Enter phone number to retrieve booking history        |
| **Admin CRUD for deals**                | Create, update, deactivate deals via admin dashboard  |
| **Auto-expiry scheduler**               | Backend job runs every 60 s to deactivate expired deals |

---

## 🔌 REST API Endpoints

### Public

| Method | Endpoint               | Description                        |
|--------|------------------------|------------------------------------|
| GET    | `/api/deals`           | Get all currently active deals     |
| POST   | `/api/bookings`        | Book a flight (phone + name)       |
| GET    | `/api/bookings/lookup` | Look up bookings by `?phone=...`   |
| DELETE | `/api/bookings/{id}`   | Cancel a booking                   |

### Admin

| Method | Endpoint              | Description             |
|--------|-----------------------|-------------------------|
| GET    | `/api/admin/deals`    | Get all deals           |
| POST   | `/api/admin/deals`    | Create a new deal       |
| PUT    | `/api/admin/deals/{id}` | Update a deal          |
| DELETE | `/api/admin/deals/{id}` | Deactivate a deal      |
| GET    | `/api/bookings/admin` | Get all bookings        |

---

## 🎨 Design Patterns Used

### 1. Singleton Pattern
**Where:** All Spring `@Service` and `@Repository` beans  
**Why:** Spring manages beans as singletons by default. A single shared instance of `SpecialDealService`, `BookingService`, etc. is reused across all HTTP requests, avoiding redundant instantiation and ensuring shared state (e.g. scheduled jobs) is consistent.

### 2. Repository Pattern
**Where:** `SpecialDealRepository`, `BookingRepository` — both extend `JpaRepository`  
**Why:** Abstracts all data access logic behind a clean interface. Controllers and Services never write raw SQL or interact with `EntityManager` directly. Spring Data generates the implementation at runtime. This decouples business logic from persistence, making it easy to swap databases (e.g., H2 → MySQL) with a single config change.

### 3. Service Layer Pattern
**Where:** `SpecialDealService`, `BookingService`  
**Why:** All business logic (validation, entity construction, scheduling) lives here. Controllers are thin and only handle HTTP concerns. This separation of concerns improves testability: services can be unit-tested independently of HTTP.

### 4. DTO (Data Transfer Object) Pattern
**Where:** `Dtos.java` — `SpecialDealRequest`, `SpecialDealResponse`, `BookingRequest`, `BookingResponse`  
**Why:** Decouples the internal JPA entity model from the API contract. Prevents **over-posting attacks** (clients can't set `active=true` or `createdAt` from the request body). Also allows the response shape to include computed fields (e.g. `minutesRemaining`) not stored in the database.

### 5. Factory Method Pattern
**Where:** `BookingService.createBooking()`, `SpecialDealService.createDeal()`  
**Why:** Centralizes entity construction logic in a single method. All validation, defaults, and relationship wiring happen in one place. Callers (controllers) only provide a DTO and receive a fully formed entity — they don't know *how* it's built.

### 6. Observer Pattern (via Spring Scheduler)
**Where:** `SpecialDealService.expireOutdatedDeals()` annotated with `@Scheduled(fixedRate = 60000)`  
**Why:** The scheduler acts as an observer that "listens" to time. Every 60 seconds it queries for expired deals and deactivates them. This implements the requirement _"Special deals are only good for a limited amount of time"_ without any manual intervention — the system self-maintains.

### 7. Facade Pattern
**Where:** `SpecialDealController`, `BookingController`  
**Why:** REST Controllers act as facades — they present a simplified, unified HTTP interface over the underlying complexity of service calls, validation, transaction management, and entity-to-DTO mapping. Clients interact only with clean HTTP endpoints.

---

## 🗂 Project Structure

```
bookmyflight/
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/bookmyflight/
│       │   ├── BookMyFlightApplication.java   ← Entry point + pattern docs
│       │   ├── model/
│       │   │   ├── SpecialDeal.java            ← JPA Entity
│       │   │   └── Booking.java               ← JPA Entity
│       │   ├── repository/
│       │   │   ├── SpecialDealRepository.java  ← Repository Pattern
│       │   │   └── BookingRepository.java
│       │   ├── service/
│       │   │   ├── SpecialDealService.java     ← Service + Observer Pattern
│       │   │   └── BookingService.java         ← Service + Factory Method
│       │   ├── dto/
│       │   │   └── Dtos.java                  ← DTO Pattern
│       │   ├── controller/
│       │   │   ├── SpecialDealController.java  ← Facade Pattern
│       │   │   └── BookingController.java
│       │   └── config/
│       │       ├── WebConfig.java             ← CORS configuration
│       │       └── GlobalExceptionHandler.java
│       └── resources/
│           ├── application.properties          ← H2 config
│           └── data.sql                        ← Seed data
│
└── frontend/
    ├── package.json
    └── src/
        ├── App.js                              ← Router + Navbar
        ├── App.css                             ← Global design system
        ├── index.js
        ├── services/
        │   └── api.js                          ← Axios API layer
        └── pages/
            ├── HomePage.js                     ← Live deals + countdown timers
            ├── BookingPage.js                  ← Booking form (phone-based)
            ├── MyBookingsPage.js               ← Lookup by phone
            └── AdminPage.js                    ← CRUD dashboard
```
