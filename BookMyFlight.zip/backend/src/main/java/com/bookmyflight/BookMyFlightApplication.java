package com.bookmyflight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main entry point for the Book My Flight application.
 *
 * Design Patterns used in this application:
 * ============================================
 * 1. SINGLETON      - Spring Beans (Services, Repositories) are singletons by default.
 *                     Ensures a single shared instance across the application lifecycle.
 *
 * 2. REPOSITORY     - SpecialDealRepository and BookingRepository extend JpaRepository,
 *                     abstracting data access logic behind a clean interface.
 *                     Isolates persistence concerns from business logic.
 *
 * 3. SERVICE LAYER  - Business logic is encapsulated in SpecialDealService and BookingService.
 *                     Controllers delegate to services, keeping them thin and testable.
 *
 * 4. DTO (Data Transfer Object) - DTOs (BookingRequest, SpecialDealDTO) decouple internal
 *                     entity models from the API contract exposed to clients.
 *                     Prevents over-posting and controls what data is shared.
 *
 * 5. FACTORY METHOD - BookingService.createBooking() acts as a factory for Booking entities,
 *                     centralizing construction logic with validation in one place.
 *
 * 6. OBSERVER       - Spring's @Scheduled annotation observes the clock and triggers
 *                     periodic cleanup of expired deals (event-driven scheduling).
 *
 * 7. FACADE         - REST Controllers act as facades, providing simplified endpoints
 *                     over complex underlying service and persistence operations.
 */
@SpringBootApplication
@EnableScheduling
public class BookMyFlightApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookMyFlightApplication.class, args);
    }
}
