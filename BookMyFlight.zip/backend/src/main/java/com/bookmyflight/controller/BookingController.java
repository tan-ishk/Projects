package com.bookmyflight.controller;

import com.bookmyflight.dto.Dtos.*;
import com.bookmyflight.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Facade Pattern: Provides a clean HTTP interface for booking operations.
 * Customers use phone numbers — no login required.
 */
@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class BookingController {

    private final BookingService bookingService;

    /**
     * POST /api/bookings — Book a flight using a special deal.
     * Customer identifies with phone number only (no password).
     */
    @PostMapping
    public ResponseEntity<BookingResponse> bookFlight(
            @Valid @RequestBody BookingRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(bookingService.createBooking(request));
    }

    /**
     * GET /api/bookings/lookup?phone=... — Look up booking history by phone number.
     */
    @GetMapping("/lookup")
    public ResponseEntity<List<BookingResponse>> getMyBookings(
            @RequestParam String phone) {
        return ResponseEntity.ok(bookingService.getBookingsByPhone(phone));
    }

    /**
     * DELETE /api/bookings/{id} — Cancel a booking.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<BookingResponse> cancelBooking(@PathVariable Long id) {
        return ResponseEntity.ok(bookingService.cancelBooking(id));
    }

    /**
     * GET /api/bookings/admin — All bookings (admin view).
     */
    @GetMapping("/admin")
    public ResponseEntity<List<BookingResponse>> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }
}
