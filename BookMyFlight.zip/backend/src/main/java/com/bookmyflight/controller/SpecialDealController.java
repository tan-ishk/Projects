package com.bookmyflight.controller;

import com.bookmyflight.dto.Dtos.*;
import com.bookmyflight.service.SpecialDealService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Facade Pattern: Provides a clean, simplified HTTP interface over
 * the underlying SpecialDealService and repository operations.
 *
 * Public endpoints: GET /api/deals (home page deals)
 * Admin endpoints:  POST, PUT, DELETE /api/admin/deals
 */
@RestController
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class SpecialDealController {

    private final SpecialDealService dealService;

    // ─── Public Endpoints ────────────────────────────────────────────────────

    /**
     * GET /api/deals
     * Returns only currently active, non-expired deals for the home page.
     * Re-fetched dynamically so the page always shows live deals.
     */
    @GetMapping("/api/deals")
    public ResponseEntity<List<SpecialDealResponse>> getActiveDeals() {
        return ResponseEntity.ok(dealService.getActiveDeals());
    }

    // ─── Admin CRUD Endpoints ─────────────────────────────────────────────────

    /**
     * GET /api/admin/deals — All deals (for admin management dashboard)
     */
    @GetMapping("/api/admin/deals")
    public ResponseEntity<List<SpecialDealResponse>> getAllDeals() {
        return ResponseEntity.ok(dealService.getAllDeals());
    }

    /**
     * POST /api/admin/deals — Create a new special deal
     */
    @PostMapping("/api/admin/deals")
    public ResponseEntity<SpecialDealResponse> createDeal(
            @Valid @RequestBody SpecialDealRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(dealService.createDeal(request));
    }

    /**
     * PUT /api/admin/deals/{id} — Update an existing deal
     */
    @PutMapping("/api/admin/deals/{id}")
    public ResponseEntity<SpecialDealResponse> updateDeal(
            @PathVariable Long id,
            @Valid @RequestBody SpecialDealRequest request) {
        return ResponseEntity.ok(dealService.updateDeal(id, request));
    }

    /**
     * DELETE /api/admin/deals/{id} — Soft-delete (deactivate) a deal
     */
    @DeleteMapping("/api/admin/deals/{id}")
    public ResponseEntity<Void> deleteDeal(@PathVariable Long id) {
        dealService.deleteDeal(id);
        return ResponseEntity.noContent().build();
    }
}
