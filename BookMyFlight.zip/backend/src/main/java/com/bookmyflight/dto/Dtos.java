package com.bookmyflight.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO Pattern: Decouples API contracts from internal JPA entities.
 * Prevents over-posting attacks and controls serialization boundaries.
 */
public class Dtos {

    // ─── SpecialDeal DTOs ───────────────────────────────────────────────────

    /**
     * Request DTO for creating or updating a special deal (Admin only).
     */
    @Data
    public static class SpecialDealRequest {
        @NotBlank(message = "Departure city is required")
        private String departureCity;

        @NotBlank(message = "Arrival city is required")
        private String arrivalCity;

        @NotNull(message = "Cost is required")
        @DecimalMin(value = "0.01", message = "Cost must be greater than 0")
        private BigDecimal cost;

        @NotNull(message = "Valid until date is required")
        @Future(message = "Expiry date must be in the future")
        private LocalDateTime validUntil;
    }

    /**
     * Response DTO for special deals shown on the home page.
     */
    @Data
    public static class SpecialDealResponse {
        private Long id;
        private String departureCity;
        private String arrivalCity;
        private BigDecimal cost;
        private LocalDateTime validUntil;
        private Boolean active;
        private LocalDateTime createdAt;
        private long minutesRemaining; // how many minutes before this deal expires
    }

    // ─── Booking DTOs ───────────────────────────────────────────────────────

    /**
     * Request DTO for booking a flight.
     * Uses phone number instead of username/password per requirements.
     */
    @Data
    public static class BookingRequest {
        @NotBlank(message = "Customer name is required")
        private String customerName;

        @NotBlank(message = "Phone number is required")
        @Pattern(regexp = "^[+]?[0-9]{10,15}$", message = "Please enter a valid phone number (10–15 digits)")
        private String customerPhone;

        @NotNull(message = "Deal ID is required")
        private Long dealId;
    }

    /**
     * Response DTO for a confirmed booking.
     */
    @Data
    public static class BookingResponse {
        private Long bookingId;
        private String customerName;
        private String customerPhone;
        private String departureCity;
        private String arrivalCity;
        private BigDecimal bookedCost;
        private String status;
        private LocalDateTime bookedAt;
    }
}
