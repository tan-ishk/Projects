package com.bookmyflight.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Entity representing a flight booking made by a customer.
 * Customers identify themselves using a phone number (no username/password).
 */
@Entity
@Table(name = "booking")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Customer's phone number used as identifier.
     * Requirement: "(S)He may not register using username/password — a phone no could be used instead."
     */
    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "^[+]?[0-9]{10,15}$", message = "Please provide a valid phone number")
    @Column(nullable = false)
    private String customerPhone;

    @NotBlank(message = "Customer name is required")
    @Column(nullable = false)
    private String customerName;

    /**
     * Snapshot of deal details at booking time (deal may expire/change later).
     */
    @Column(nullable = false)
    private String departureCity;

    @Column(nullable = false)
    private String arrivalCity;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal bookedCost;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "special_deal_id")
    private SpecialDeal specialDeal;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private BookingStatus status = BookingStatus.CONFIRMED;

    @Column(nullable = false, updatable = false)
    @Builder.Default
    private LocalDateTime bookedAt = LocalDateTime.now();

    public enum BookingStatus {
        CONFIRMED, CANCELLED, PENDING
    }
}
