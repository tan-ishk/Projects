package com.bookmyflight.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Entity representing a time-limited special flight deal.
 * Created/managed by the marketing department (Admin CRUD).
 * Deals have a validUntil timestamp — expired deals are excluded from home page.
 */
@Entity
@Table(name = "special_deal")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SpecialDeal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Departure city is required")
    @Column(nullable = false)
    private String departureCity;

    @NotBlank(message = "Arrival city is required")
    @Column(nullable = false)
    private String arrivalCity;

    @NotNull(message = "Cost is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Cost must be positive")
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal cost;

    /**
     * Deals are only valid until this timestamp.
     * This satisfies the requirement: "Special deals are only good for a limited amount of time."
     */
    @NotNull(message = "Valid until date is required")
    @Column(nullable = false)
    private LocalDateTime validUntil;

    @Column(nullable = false)
    @Builder.Default
    private Boolean active = true;

    @Column(nullable = false, updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    /**
     * Convenience method to check if this deal is currently valid.
     */
    @Transient
    public boolean isCurrentlyValid() {
        return active && LocalDateTime.now().isBefore(validUntil);
    }
}
