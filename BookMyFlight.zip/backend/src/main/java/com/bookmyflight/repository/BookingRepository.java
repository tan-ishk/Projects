package com.bookmyflight.repository;

import com.bookmyflight.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository Pattern: Abstracts persistence for Booking entities.
 */
@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    /**
     * Retrieve all bookings made by a specific customer phone number.
     */
    List<Booking> findByCustomerPhone(String customerPhone);

    /**
     * Find all bookings linked to a particular special deal.
     */
    List<Booking> findBySpecialDealId(Long dealId);
}
