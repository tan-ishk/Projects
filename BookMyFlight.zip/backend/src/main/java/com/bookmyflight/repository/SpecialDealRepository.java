package com.bookmyflight.repository;

import com.bookmyflight.model.SpecialDeal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Repository Pattern: Abstracts persistence operations for SpecialDeal.
 * Spring Data JPA generates the implementation at runtime.
 */
@Repository
public interface SpecialDealRepository extends JpaRepository<SpecialDeal, Long> {

    /**
     * Find all active deals that have not yet expired.
     * Used on the home page to show currently valid special deals.
     * Satisfies: "These special deals... change during the day, so it can't be static."
     */
    @Query("SELECT d FROM SpecialDeal d WHERE d.active = TRUE AND d.validUntil > :now ORDER BY d.validUntil ASC")
    List<SpecialDeal> findActiveDeals(LocalDateTime now);

    /**
     * Find all deals that have expired and are still marked active (for scheduled cleanup).
     */
    @Query("SELECT d FROM SpecialDeal d WHERE d.active = TRUE AND d.validUntil <= :now")
    List<SpecialDeal> findExpiredActiveDeals(LocalDateTime now);
}
