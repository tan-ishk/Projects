package com.bookmyflight.service;

import com.bookmyflight.dto.Dtos.*;
import com.bookmyflight.model.Booking;
import com.bookmyflight.model.SpecialDeal;
import com.bookmyflight.repository.BookingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service Layer Pattern: Centralizes booking business logic.
 * Factory Method Pattern: createBooking() constructs Booking entities
 *   from DTOs, encapsulating all construction and validation in one place.
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class BookingService {

    private final BookingRepository bookingRepository;
    private final SpecialDealService dealService;

    /**
     * Factory Method Pattern:
     * Creates a new Booking entity from the incoming request.
     * Validates that the chosen deal is still active before confirming.
     */
    public BookingResponse createBooking(BookingRequest request) {
        SpecialDeal deal = dealService.getDealById(request.getDealId());

        // Business rule: deal must still be valid at time of booking
        if (!deal.isCurrentlyValid()) {
            throw new IllegalStateException(
                "Sorry, this special deal has expired. Please choose another deal.");
        }

        // Factory construction of the Booking entity
        Booking booking = Booking.builder()
                .customerName(request.getCustomerName())
                .customerPhone(request.getCustomerPhone())
                .departureCity(deal.getDepartureCity())
                .arrivalCity(deal.getArrivalCity())
                .bookedCost(deal.getCost())
                .specialDeal(deal)
                .status(Booking.BookingStatus.CONFIRMED)
                .bookedAt(LocalDateTime.now())
                .build();

        Booking saved = bookingRepository.save(booking);
        log.info("Booking confirmed: ID={} Phone={} Route={}->{}", 
                 saved.getId(), saved.getCustomerPhone(),
                 saved.getDepartureCity(), saved.getArrivalCity());

        return toResponse(saved);
    }

    /**
     * Retrieve booking history for a given phone number.
     * This allows customers to look up their bookings without a password.
     */
    @Transactional(readOnly = true)
    public List<BookingResponse> getBookingsByPhone(String phone) {
        return bookingRepository.findByCustomerPhone(phone).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * Admin: Get all bookings.
     */
    @Transactional(readOnly = true)
    public List<BookingResponse> getAllBookings() {
        return bookingRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * Cancel a booking (soft status update).
     */
    public BookingResponse cancelBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found: " + bookingId));
        booking.setStatus(Booking.BookingStatus.CANCELLED);
        return toResponse(bookingRepository.save(booking));
    }

    // ─── DTO Mapper ──────────────────────────────────────────────────────────

    private BookingResponse toResponse(Booking booking) {
        BookingResponse response = new BookingResponse();
        response.setBookingId(booking.getId());
        response.setCustomerName(booking.getCustomerName());
        response.setCustomerPhone(booking.getCustomerPhone());
        response.setDepartureCity(booking.getDepartureCity());
        response.setArrivalCity(booking.getArrivalCity());
        response.setBookedCost(booking.getBookedCost());
        response.setStatus(booking.getStatus().name());
        response.setBookedAt(booking.getBookedAt());
        return response;
    }
}
