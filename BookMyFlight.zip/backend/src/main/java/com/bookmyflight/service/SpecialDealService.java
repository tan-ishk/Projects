package com.bookmyflight.service;

import com.bookmyflight.dto.Dtos.*;
import com.bookmyflight.model.SpecialDeal;
import com.bookmyflight.repository.SpecialDealRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service Layer Pattern: Encapsulates all business logic for special deals.
 * Controllers remain thin and delegate here.
 *
 * Observer / Scheduled Pattern: @Scheduled drives periodic expiry checks,
 * simulating an event-driven observer that reacts to time passing.
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class SpecialDealService {

    private final SpecialDealRepository dealRepository;

    // ─── Admin CRUD ─────────────────────────────────────────────────────────

    /**
     * Admin: Create a new special deal.
     * Factory Method pattern: constructs SpecialDeal entity from DTO.
     */
    public SpecialDealResponse createDeal(SpecialDealRequest request) {
        SpecialDeal deal = SpecialDeal.builder()
                .departureCity(request.getDepartureCity())
                .arrivalCity(request.getArrivalCity())
                .cost(request.getCost())
                .validUntil(request.getValidUntil())
                .active(true)
                .createdAt(LocalDateTime.now())
                .build();
        return toResponse(dealRepository.save(deal));
    }

    /**
     * Admin: Update an existing special deal.
     */
    public SpecialDealResponse updateDeal(Long id, SpecialDealRequest request) {
        SpecialDeal deal = dealRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Deal not found: " + id));
        deal.setDepartureCity(request.getDepartureCity());
        deal.setArrivalCity(request.getArrivalCity());
        deal.setCost(request.getCost());
        deal.setValidUntil(request.getValidUntil());
        return toResponse(dealRepository.save(deal));
    }

    /**
     * Admin: Soft-delete (deactivate) a deal.
     */
    public void deleteDeal(Long id) {
        SpecialDeal deal = dealRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Deal not found: " + id));
        deal.setActive(false);
        dealRepository.save(deal);
    }

    /**
     * Admin: Get all deals (active and expired) for management view.
     */
    @Transactional(readOnly = true)
    public List<SpecialDealResponse> getAllDeals() {
        return dealRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    // ─── Public API ─────────────────────────────────────────────────────────

    /**
     * Home page: Returns only currently active and non-expired deals.
     * Since validUntil is dynamic, every call re-queries for fresh results.
     */
    @Transactional(readOnly = true)
    public List<SpecialDealResponse> getActiveDeals() {
        return dealRepository.findActiveDeals(LocalDateTime.now()).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public SpecialDeal getDealById(Long id) {
        return dealRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Deal not found: " + id));
    }

    // ─── Observer / Scheduled Expiry Cleanup ────────────────────────────────

    /**
     * Observer Pattern (via @Scheduled):
     * Every 60 seconds, this method is invoked automatically by Spring's task scheduler.
     * It deactivates any deals whose validUntil time has passed.
     * This keeps deals "live" without any manual intervention.
     */
    @Scheduled(fixedRate = 60000)
    public void expireOutdatedDeals() {
        List<SpecialDeal> expired = dealRepository.findExpiredActiveDeals(LocalDateTime.now());
        expired.forEach(deal -> deal.setActive(false));
        if (!expired.isEmpty()) {
            dealRepository.saveAll(expired);
            log.info("Expired {} outdated deals", expired.size());
        }
    }

    // ─── Mapper (DTO Conversion) ─────────────────────────────────────────────

    private SpecialDealResponse toResponse(SpecialDeal deal) {
        SpecialDealResponse response = new SpecialDealResponse();
        response.setId(deal.getId());
        response.setDepartureCity(deal.getDepartureCity());
        response.setArrivalCity(deal.getArrivalCity());
        response.setCost(deal.getCost());
        response.setValidUntil(deal.getValidUntil());
        response.setActive(deal.getActive());
        response.setCreatedAt(deal.getCreatedAt());
        long minutes = ChronoUnit.MINUTES.between(LocalDateTime.now(), deal.getValidUntil());
        response.setMinutesRemaining(Math.max(0, minutes));
        return response;
    }
}
