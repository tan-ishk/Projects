import React, { useState, useEffect, useCallback } from 'react';
import {
  adminGetAllDeals, adminCreateDeal, adminUpdateDeal, adminDeleteDeal,
  adminGetAllBookings
} from '../services/api';

// ─── Deal Form Modal ──────────────────────────────────────────────────────────
function DealFormModal({ deal, onClose, onSave }) {
  const isEdit = !!deal?.id;

  const defaultValidUntil = () => {
    const d = new Date();
    d.setHours(d.getHours() + 6);
    return d.toISOString().slice(0, 16);
  };

  const [form, setForm] = useState({
    departureCity: deal?.departureCity || '',
    arrivalCity:   deal?.arrivalCity || '',
    cost:          deal?.cost || '',
    validUntil:    deal?.validUntil ? new Date(deal.validUntil).toISOString().slice(0, 16) : defaultValidUntil(),
  });
  const [errors, setErrors]     = useState({});
  const [saving, setSaving]     = useState(false);
  const [apiError, setApiError] = useState('');

  const validate = () => {
    const errs = {};
    if (!form.departureCity.trim()) errs.departureCity = 'Required';
    if (!form.arrivalCity.trim())   errs.arrivalCity   = 'Required';
    if (!form.cost || isNaN(form.cost) || Number(form.cost) <= 0) errs.cost = 'Must be a positive number';
    if (!form.validUntil) errs.validUntil = 'Required';
    else if (new Date(form.validUntil) <= new Date()) errs.validUntil = 'Must be in the future';
    return errs;
  };

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
    if (errors[name]) setErrors(er => ({ ...er, [name]: '' }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setSaving(true);
    setApiError('');
    try {
      const payload = {
        departureCity: form.departureCity.trim(),
        arrivalCity:   form.arrivalCity.trim(),
        cost:          parseFloat(form.cost),
        validUntil:    new Date(form.validUntil).toISOString(),
      };
      if (isEdit) await adminUpdateDeal(deal.id, payload);
      else         await adminCreateDeal(payload);
      onSave();
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to save deal.';
      setApiError(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <div className="modal-header">
          <h3 className="modal-title">{isEdit ? 'Edit Deal' : 'Create New Deal'}</h3>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        {apiError && <div className="alert alert-error">⚠ {apiError}</div>}

        <form onSubmit={handleSubmit} noValidate>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 1rem' }}>
            <div className="form-group">
              <label className="form-label">Departure City</label>
              <input name="departureCity" type="text" className={`form-input ${errors.departureCity ? 'error' : ''}`}
                placeholder="e.g. Mumbai" value={form.departureCity} onChange={handleChange} />
              {errors.departureCity && <p className="form-error">{errors.departureCity}</p>}
            </div>
            <div className="form-group">
              <label className="form-label">Arrival City</label>
              <input name="arrivalCity" type="text" className={`form-input ${errors.arrivalCity ? 'error' : ''}`}
                placeholder="e.g. Delhi" value={form.arrivalCity} onChange={handleChange} />
              {errors.arrivalCity && <p className="form-error">{errors.arrivalCity}</p>}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Cost (₹)</label>
            <input name="cost" type="number" min="1" step="0.01"
              className={`form-input ${errors.cost ? 'error' : ''}`}
              placeholder="e.g. 2999" value={form.cost} onChange={handleChange} />
            {errors.cost && <p className="form-error">{errors.cost}</p>}
          </div>

          <div className="form-group">
            <label className="form-label">Valid Until</label>
            <input name="validUntil" type="datetime-local"
              className={`form-input ${errors.validUntil ? 'error' : ''}`}
              value={form.validUntil} onChange={handleChange} />
            {errors.validUntil && <p className="form-error">{errors.validUntil}</p>}
          </div>

          <div style={{ display: 'flex', gap: '0.75rem', marginTop: '0.5rem' }}>
            <button type="button" className="btn btn-ghost" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" style={{ flex: 1 }} disabled={saving}>
              {saving ? 'Saving...' : isEdit ? 'Update Deal' : 'Create Deal'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── Main Admin Page ──────────────────────────────────────────────────────────
export default function AdminPage() {
  const [tab, setTab]         = useState('deals');
  const [deals, setDeals]     = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal]     = useState(null); // null | 'create' | deal object
  const [error, setError]     = useState('');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [d, b] = await Promise.all([adminGetAllDeals(), adminGetAllBookings()]);
      setDeals(d.data);
      setBookings(b.data);
    } catch {
      setError('Failed to load admin data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleDelete = async (id) => {
    if (!window.confirm('Deactivate this deal?')) return;
    try {
      await adminDeleteDeal(id);
      setDeals(ds => ds.map(d => d.id === id ? { ...d, active: false } : d));
    } catch {
      alert('Failed to deactivate deal.');
    }
  };

  const handleModalSave = () => {
    setModal(null);
    loadData();
  };

  const formatDate = (iso) => new Date(iso).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' });

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">
          <span style={{ color: 'var(--gold)' }}>Admin</span> Dashboard
        </h1>
        <p className="page-subtitle">Manage special deals and view all bookings.</p>
      </div>

      <div className="tab-bar">
        <button className={`tab-btn ${tab === 'deals' ? 'active' : ''}`} onClick={() => setTab('deals')}>
          ✈ Special Deals
        </button>
        <button className={`tab-btn ${tab === 'bookings' ? 'active' : ''}`} onClick={() => setTab('bookings')}>
          📋 All Bookings
        </button>
      </div>

      {error && <div className="alert alert-error">⚠ {error}</div>}

      {loading ? (
        <div className="loading"><div className="spinner" /> Loading...</div>
      ) : tab === 'deals' ? (
        <>
          <div className="section-header">
            <div>
              <h2 className="section-title">Special Deals</h2>
              <p style={{ color: 'var(--muted)', fontSize: '0.82rem', marginTop: 2 }}>{deals.length} total deals</p>
            </div>
            <button className="btn btn-primary" onClick={() => setModal('create')}>
              + New Deal
            </button>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Route</th>
                  <th>Cost</th>
                  <th>Valid Until</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {deals.map(deal => {
                  const expired = new Date(deal.validUntil) <= new Date();
                  const isActive = deal.active && !expired;
                  return (
                    <tr key={deal.id}>
                      <td style={{ color: 'var(--muted)', fontSize: '0.82rem' }}>#{deal.id}</td>
                      <td>
                        <span style={{ fontWeight: 600 }}>{deal.departureCity}</span>
                        <span style={{ color: 'var(--sky)', margin: '0 0.35rem' }}>→</span>
                        <span style={{ fontWeight: 600 }}>{deal.arrivalCity}</span>
                      </td>
                      <td style={{ color: 'var(--gold)', fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                        ₹{Number(deal.cost).toLocaleString('en-IN')}
                      </td>
                      <td style={{ fontSize: '0.85rem' }}>{formatDate(deal.validUntil)}</td>
                      <td>
                        <span className={`badge ${isActive ? 'badge-active' : 'badge-expired'}`}>
                          {isActive ? 'Active' : expired ? 'Expired' : 'Inactive'}
                        </span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: '0.4rem' }}>
                          <button className="btn btn-ghost btn-sm" onClick={() => setModal(deal)}>Edit</button>
                          {deal.active && (
                            <button className="btn btn-danger btn-sm" onClick={() => handleDelete(deal.id)}>
                              Deactivate
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <>
          <div className="section-header">
            <div>
              <h2 className="section-title">All Bookings</h2>
              <p style={{ color: 'var(--muted)', fontSize: '0.82rem', marginTop: 2 }}>{bookings.length} total bookings</p>
            </div>
          </div>

          {bookings.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">📋</div>
              <h3>No bookings yet</h3>
              <p>Bookings will appear here once customers start booking flights.</p>
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Passenger</th>
                    <th>Phone</th>
                    <th>Route</th>
                    <th>Cost</th>
                    <th>Booked At</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {bookings.map(b => (
                    <tr key={b.bookingId}>
                      <td style={{ color: 'var(--muted)', fontSize: '0.82rem' }}>
                        #BMF-{String(b.bookingId).padStart(5, '0')}
                      </td>
                      <td style={{ fontWeight: 500 }}>{b.customerName}</td>
                      <td style={{ fontSize: '0.85rem', color: 'var(--muted)' }}>{b.customerPhone}</td>
                      <td>
                        <span style={{ fontWeight: 600 }}>{b.departureCity}</span>
                        <span style={{ color: 'var(--sky)', margin: '0 0.35rem' }}>→</span>
                        <span style={{ fontWeight: 600 }}>{b.arrivalCity}</span>
                      </td>
                      <td style={{ color: 'var(--gold)', fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                        ₹{Number(b.bookedCost).toLocaleString('en-IN')}
                      </td>
                      <td style={{ fontSize: '0.82rem' }}>{formatDate(b.bookedAt)}</td>
                      <td>
                        <span className={`badge badge-${b.status.toLowerCase()}`}>{b.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {modal && (
        <DealFormModal
          deal={modal === 'create' ? null : modal}
          onClose={() => setModal(null)}
          onSave={handleModalSave}
        />
      )}
    </div>
  );
}
