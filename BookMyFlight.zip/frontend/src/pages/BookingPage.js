import React, { useState, useEffect } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { bookFlight, fetchActiveDeals } from '../services/api';

export default function BookingPage() {
  const { dealId } = useParams();
  const { state }  = useLocation();
  const navigate   = useNavigate();

  const [deal, setDeal]         = useState(state?.deal || null);
  const [loading, setLoading]   = useState(!state?.deal);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess]   = useState(null);
  const [apiError, setApiError] = useState('');

  const [form, setForm] = useState({ customerName: '', customerPhone: '' });
  const [errors, setErrors] = useState({});

  // If navigated directly without state, fetch the deal
  useEffect(() => {
    if (!deal) {
      fetchActiveDeals()
        .then(res => {
          const found = res.data.find(d => String(d.id) === String(dealId));
          if (found) setDeal(found);
          else setApiError('Deal not found or has expired.');
        })
        .catch(() => setApiError('Failed to load deal.'))
        .finally(() => setLoading(false));
    }
  }, [deal, dealId]);

  const validate = () => {
    const errs = {};
    if (!form.customerName.trim()) errs.customerName = 'Name is required';
    if (!form.customerPhone.trim()) {
      errs.customerPhone = 'Phone number is required';
    } else if (!/^[+]?[0-9]{10,15}$/.test(form.customerPhone.replace(/\s/g, ''))) {
      errs.customerPhone = 'Enter a valid phone number (10–15 digits)';
    }
    return errs;
  };

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
    if (errors[name]) setErrors(er => ({ ...er, [name]: '' }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setSubmitting(true);
    setApiError('');
    try {
      const res = await bookFlight({
        customerName:  form.customerName.trim(),
        customerPhone: form.customerPhone.trim(),
        dealId: Number(dealId),
      });
      setSuccess(res.data);
    } catch (err) {
      const msg = err.response?.data?.message || 'Booking failed. Please try again.';
      setApiError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return (
    <div className="loading"><div className="spinner" /> Loading deal...</div>
  );

  // ─── Success State ────────────────────────────────────────────────────────
  if (success) return (
    <div style={{ maxWidth: 520, margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <div style={{ fontSize: '3.5rem', marginBottom: '1rem' }}>🎉</div>
        <h2 className="page-title" style={{ marginBottom: '0.5rem' }}>
          Booking <span className="accent">Confirmed!</span>
        </h2>
        <p className="page-subtitle">Your flight has been reserved successfully.</p>
      </div>

      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div style={{ borderBottom: '1px solid var(--border)', paddingBottom: '1rem', marginBottom: '1rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
            <span style={{ color: 'var(--muted)', fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Booking ID</span>
            <span style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, color: 'var(--sky)' }}>
              #BMF-{String(success.bookingId).padStart(5, '0')}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ color: 'var(--muted)', fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Status</span>
            <span className="badge badge-confirmed">{success.status}</span>
          </div>
        </div>

        <div className="summary-box">
          <div className="summary-row">
            <span className="summary-label">Passenger</span>
            <span className="summary-value">{success.customerName}</span>
          </div>
          <div className="summary-row">
            <span className="summary-label">Phone</span>
            <span className="summary-value">{success.customerPhone}</span>
          </div>
          <div className="summary-row">
            <span className="summary-label">From</span>
            <span className="summary-value">{success.departureCity}</span>
          </div>
          <div className="summary-row">
            <span className="summary-label">To</span>
            <span className="summary-value">{success.arrivalCity}</span>
          </div>
          <div className="summary-row summary-total">
            <span className="summary-label">Total Paid</span>
            <span className="summary-value">₹{Number(success.bookedCost).toLocaleString('en-IN')}</span>
          </div>
        </div>

        <div className="alert alert-info" style={{ marginBottom: 0 }}>
          💡 Save your phone number <strong>{success.customerPhone}</strong> to look up this booking anytime.
        </div>
      </div>

      <div style={{ display: 'flex', gap: '0.75rem' }}>
        <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => navigate('/my-bookings')}>
          View My Bookings
        </button>
        <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => navigate('/')}>
          Back to Deals
        </button>
      </div>
    </div>
  );

  // ─── Booking Form ─────────────────────────────────────────────────────────
  return (
    <div style={{ maxWidth: 520, margin: '0 auto' }}>
      <button className="btn btn-ghost btn-sm" onClick={() => navigate(-1)} style={{ marginBottom: '1.5rem' }}>
        ← Back to Deals
      </button>

      <div className="page-header">
        <h1 className="page-title">Book Your <span className="accent">Flight</span></h1>
        <p className="page-subtitle">No account needed — just your name and phone number.</p>
      </div>

      {deal && (
        <div className="summary-box" style={{ marginBottom: '1.75rem' }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '1rem', marginBottom: '0.75rem', color: 'var(--sky)' }}>
            ✈ Selected Deal
          </div>
          <div className="summary-row">
            <span className="summary-label">Route</span>
            <span className="summary-value">{deal.departureCity} → {deal.arrivalCity}</span>
          </div>
          <div className="summary-row summary-total">
            <span className="summary-label">Price</span>
            <span className="summary-value">₹{Number(deal.cost).toLocaleString('en-IN')}</span>
          </div>
        </div>
      )}

      {apiError && <div className="alert alert-error">⚠ {apiError}</div>}

      <div className="card">
        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label" htmlFor="customerName">Full Name</label>
            <input
              id="customerName"
              name="customerName"
              type="text"
              className={`form-input ${errors.customerName ? 'error' : ''}`}
              placeholder="Enter your full name"
              value={form.customerName}
              onChange={handleChange}
            />
            {errors.customerName && <p className="form-error">{errors.customerName}</p>}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="customerPhone">Phone Number</label>
            <input
              id="customerPhone"
              name="customerPhone"
              type="tel"
              className={`form-input ${errors.customerPhone ? 'error' : ''}`}
              placeholder="+91 9876543210"
              value={form.customerPhone}
              onChange={handleChange}
            />
            {errors.customerPhone && <p className="form-error">{errors.customerPhone}</p>}
            <p style={{ fontSize: '0.78rem', color: 'var(--muted)', marginTop: '0.4rem' }}>
              Your phone number is your booking ID — no password required.
            </p>
          </div>

          <button
            type="submit"
            className="btn btn-gold btn-full"
            disabled={submitting}
            style={{ marginTop: '0.5rem', padding: '0.85rem' }}
          >
            {submitting ? (
              <><div className="spinner" style={{ width: 18, height: 18, borderWidth: 2 }} /> Processing...</>
            ) : (
              `Confirm Booking — ₹${deal ? Number(deal.cost).toLocaleString('en-IN') : '—'}`
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
