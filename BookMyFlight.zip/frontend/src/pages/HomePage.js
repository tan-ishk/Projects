import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchActiveDeals } from '../services/api';

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Case-insensitive city match */
const cityMatch = (a, b) => a.trim().toLowerCase() === b.trim().toLowerCase();

/**
 * Find connecting routes: leg1.arrival === leg2.departure
 * Returns array of { leg1, leg2, totalCost }
 */
function findConnectingFlights(deals, from, to) {
  const results = [];
  for (const leg1 of deals) {
    if (!cityMatch(leg1.departureCity, from)) continue;
    for (const leg2 of deals) {
      if (leg1.id === leg2.id) continue;
      if (!cityMatch(leg1.arrivalCity, leg2.departureCity)) continue;
      if (!cityMatch(leg2.arrivalCity, to)) continue;
      results.push({
        leg1,
        leg2,
        totalCost: Number(leg1.cost) + Number(leg2.cost),
      });
    }
  }
  // sort by cheapest first
  return results.sort((a, b) => a.totalCost - b.totalCost);
}

// ─── Timer ────────────────────────────────────────────────────────────────────

function CountdownTimer({ validUntil }) {
  const [secondsLeft, setSecondsLeft] = useState(() =>
    Math.max(0, Math.floor((new Date(validUntil) - new Date()) / 1000))
  );
  useEffect(() => {
    if (secondsLeft <= 0) return;
    const t = setInterval(() => setSecondsLeft(s => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [secondsLeft]);

  const hrs  = Math.floor(secondsLeft / 3600);
  const mins = Math.floor((secondsLeft % 3600) / 60);
  const secs = secondsLeft % 60;
  const isUrgent = secondsLeft < 600;
  if (secondsLeft === 0) return <span style={{ color: '#ef4444' }}>Expired</span>;
  return (
    <span className={isUrgent ? 'timer-urgent' : ''}>
      <span className={`timer-dot ${isUrgent ? 'urgent' : ''}`} />
      Expires in {hrs > 0 && `${hrs}h `}{mins > 0 && `${mins}m `}{secs}s
    </span>
  );
}

// ─── Direct Deal Card ─────────────────────────────────────────────────────────

function DealCard({ deal, onBook }) {
  return (
    <div className="card deal-card">
      <div className="deal-route">
        <div className="deal-city from">{deal.departureCity}</div>
        <div className="deal-arrow">✈<span /></div>
        <div className="deal-city to">{deal.arrivalCity}</div>
      </div>
      <div className="deal-cost">
        ₹{Number(deal.cost).toLocaleString('en-IN')}
        <small> /person</small>
      </div>
      <div className="deal-timer">
        <CountdownTimer validUntil={deal.validUntil} />
      </div>
      <button className="btn btn-gold btn-full" onClick={() => onBook(deal)}>
        Book Now →
      </button>
    </div>
  );
}

// ─── Connecting Flight Card ───────────────────────────────────────────────────

function ConnectingCard({ connection, onBook }) {
  const { leg1, leg2, totalCost } = connection;
  const via = leg1.arrivalCity;

  // Expires when the earlier leg expires (both must be valid to travel)
  const earlierExpiry = new Date(leg1.validUntil) < new Date(leg2.validUntil)
    ? leg1.validUntil : leg2.validUntil;

  return (
    <div className="card deal-card connecting-card">
      {/* "Via" pill */}
      <div className="via-badge">🔗 Connecting via {via}</div>

      {/* Route display */}
      <div className="deal-route" style={{ alignItems: 'flex-start', flexDirection: 'column', gap: '0.5rem' }}>
        {/* Leg 1 */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', width: '100%' }}>
          <div style={{ flex: 1, fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '1rem' }}>
            {leg1.departureCity}
          </div>
          <div style={{ color: 'var(--sky)', fontSize: '0.9rem' }}>✈</div>
          <div style={{ flex: 1, fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '1rem', textAlign: 'right' }}>
            {leg1.arrivalCity}
          </div>
        </div>

        {/* Connector dot */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', paddingLeft: '0.25rem' }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--sky)', opacity: 0.5 }} />
          <span style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>
            ₹{Number(leg1.cost).toLocaleString('en-IN')} · Layover at {via}
          </span>
        </div>

        {/* Leg 2 */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', width: '100%' }}>
          <div style={{ flex: 1, fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '1rem' }}>
            {leg2.departureCity}
          </div>
          <div style={{ color: 'var(--gold)', fontSize: '0.9rem' }}>✈</div>
          <div style={{ flex: 1, fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '1rem', textAlign: 'right' }}>
            {leg2.arrivalCity}
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', paddingLeft: '0.25rem' }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--gold)', opacity: 0.5 }} />
          <span style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>
            ₹{Number(leg2.cost).toLocaleString('en-IN')}
          </span>
        </div>
      </div>

      {/* Total cost */}
      <div className="deal-cost" style={{ marginTop: '0.75rem' }}>
        ₹{totalCost.toLocaleString('en-IN')}
        <small> /person (combined)</small>
      </div>

      <div className="deal-timer">
        <CountdownTimer validUntil={earlierExpiry} />
      </div>

      {/* Book both legs */}
      <div style={{ display: 'flex', gap: '0.5rem' }}>
        <button
          className="btn btn-primary"
          style={{ flex: 1, fontSize: '0.8rem' }}
          onClick={() => onBook(leg1)}
        >
          Book Leg 1
        </button>
        <button
          className="btn btn-gold"
          style={{ flex: 1, fontSize: '0.8rem' }}
          onClick={() => onBook(leg2)}
        >
          Book Leg 2
        </button>
      </div>
    </div>
  );
}

// ─── Search Bar ───────────────────────────────────────────────────────────────

function SearchBar({ onSearch, allCities }) {
  const [from, setFrom] = useState('');
  const [to,   setTo]   = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    onSearch(from.trim(), to.trim());
  };

  const handleClear = () => {
    setFrom(''); setTo('');
    onSearch('', '');
  };

  return (
    <form onSubmit={handleSubmit} className="search-bar">
      <div className="search-field">
        <label className="form-label">From</label>
        <input
          type="text"
          className="form-input"
          placeholder="e.g. Kolkata"
          value={from}
          onChange={e => setFrom(e.target.value)}
          list="cities-from"
        />
        <datalist id="cities-from">
          {allCities.map(c => <option key={c} value={c} />)}
        </datalist>
      </div>

      <div className="search-swap" onClick={() => { setFrom(to); setTo(from); }} title="Swap cities">
        ⇄
      </div>

      <div className="search-field">
        <label className="form-label">To</label>
        <input
          type="text"
          className="form-input"
          placeholder="e.g. Delhi"
          value={to}
          onChange={e => setTo(e.target.value)}
          list="cities-to"
        />
        <datalist id="cities-to">
          {allCities.map(c => <option key={c} value={c} />)}
        </datalist>
      </div>

      <div className="search-actions">
        <button type="submit" className="btn btn-primary" disabled={!from || !to}>
          Search
        </button>
        {(from || to) && (
          <button type="button" className="btn btn-ghost" onClick={handleClear}>
            Clear
          </button>
        )}
      </div>
    </form>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function HomePage() {
  const [deals, setDeals]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState('');
  const [searchFrom, setSearchFrom] = useState('');
  const [searchTo,   setSearchTo]   = useState('');
  const navigate = useNavigate();

  const loadDeals = useCallback(async () => {
    try {
      const res = await fetchActiveDeals();
      setDeals(res.data);
      setError('');
    } catch {
      setError('Unable to load deals. Is the backend running?');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDeals();
    const interval = setInterval(loadDeals, 30000);
    return () => clearInterval(interval);
  }, [loadDeals]);

  // All unique city names for autocomplete
  const allCities = [...new Set(
    deals.flatMap(d => [d.departureCity, d.arrivalCity])
  )].sort();

  const isSearching = searchFrom && searchTo;

  // Direct matches
  const directDeals = isSearching
    ? deals.filter(d =>
        cityMatch(d.departureCity, searchFrom) &&
        cityMatch(d.arrivalCity,   searchTo)
      )
    : deals;

  // Connecting flights (only when searching and no direct found)
  const connectingFlights = isSearching && directDeals.length === 0
    ? findConnectingFlights(deals, searchFrom, searchTo)
    : [];

  const noResults = isSearching && directDeals.length === 0 && connectingFlights.length === 0;

  return (
    <div>
      {/* Hero */}
      <div className="hero">
        <span className="hero-plane">✈</span>
        <h1 className="hero-title">
          Fly More,<br />
          <span style={{ color: 'var(--sky)' }}>Pay Less.</span>
        </h1>
        <p className="hero-sub">
          Search for flights or grab time-limited deals. No login needed — just your phone number.
        </p>
        <div className="hero-badge">
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#10b981', display: 'inline-block', animation: 'pulse 2s infinite' }} />
          Live deals · Updated in real-time
        </div>
      </div>

      {/* Search Bar */}
      {!loading && deals.length > 0 && (
        <SearchBar
          onSearch={(f, t) => { setSearchFrom(f); setSearchTo(t); }}
          allCities={allCities}
        />
      )}

      {error && <div className="alert alert-error">⚠ {error}</div>}

      {loading ? (
        <div className="loading"><div className="spinner" /> Loading deals...</div>
      ) : (
        <>
          {/* ── Direct Flights ── */}
          <div className="section-header" style={{ marginTop: '2rem' }}>
            <h2 className="section-title">
              {isSearching
                ? directDeals.length > 0
                  ? `✈ Direct: ${searchFrom} → ${searchTo}`
                  : `No direct flights: ${searchFrom} → ${searchTo}`
                : "Today's Special Deals"}
            </h2>
            {!isSearching && (
              <span className="section-count">
                {deals.length} deal{deals.length !== 1 ? 's' : ''} available
              </span>
            )}
          </div>

          {!isSearching && deals.length === 0 && (
            <div className="empty-state">
              <div className="empty-icon">🎫</div>
              <h3>No active deals right now</h3>
              <p>Check back soon — the marketing team updates deals throughout the day.</p>
            </div>
          )}

          {directDeals.length > 0 && (
            <div className="deals-grid">
              {directDeals.map(deal => (
                <DealCard
                  key={deal.id}
                  deal={deal}
                  onBook={() => navigate(`/book/${deal.id}`, { state: { deal } })}
                />
              ))}
            </div>
          )}

          {/* ── Connecting Flights (shown only when no direct) ── */}
          {connectingFlights.length > 0 && (
            <>
              <div className="section-header" style={{ marginTop: '2.5rem' }}>
                <h2 className="section-title" style={{ color: 'var(--sky)' }}>
                  🔗 Connecting Flights Found
                </h2>
                <span className="section-count">{connectingFlights.length} option{connectingFlights.length !== 1 ? 's' : ''}</span>
              </div>
              <div className="alert alert-info" style={{ marginBottom: '1.5rem' }}>
                No direct flight from <strong>{searchFrom}</strong> to <strong>{searchTo}</strong>.
                Here are connecting routes using our active deals — book each leg separately.
              </div>
              <div className="deals-grid">
                {connectingFlights.map((conn, i) => (
                  <ConnectingCard
                    key={i}
                    connection={conn}
                    onBook={(deal) => navigate(`/book/${deal.id}`, { state: { deal } })}
                  />
                ))}
              </div>
            </>
          )}

          {/* ── Truly no results ── */}
          {noResults && (
            <div className="empty-state">
              <div className="empty-icon">🗺️</div>
              <h3>No flights found</h3>
              <p>
                We couldn't find any direct or connecting deals from{' '}
                <strong>{searchFrom}</strong> to <strong>{searchTo}</strong> right now.
                <br />Try a different route or check back soon for new deals.
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
