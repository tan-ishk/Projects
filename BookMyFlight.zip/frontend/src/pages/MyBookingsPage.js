import React, { useState } from 'react';
import { lookupBookings, cancelBooking } from '../services/api';

function BookingCard({ booking, onCancel }) {
  const [cancelling, setCancelling] = useState(false);

  const handleCancel = async () => {
    if (!window.confirm('Cancel this booking?')) return;
    setCancelling(true);
    try { await onCancel(booking.bookingId); }
    finally { setCancelling(false); }
  };

  const date = new Date(booking.bookedAt).toLocaleString('en-IN', {
    dateStyle: 'medium', timeStyle: 'short'
  });

  return (
    <div className="card" style={{ marginBottom: '1rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
        <div>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '0.8rem', color: 'var(--sky)', letterSpacing: '0.06em', marginBottom: '0.25rem' }}>
            #BMF-{String(booking.bookingId).padStart(5, '0')}
          </div>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '1.1rem' }}>
            {booking.departureCity} → {booking.arrivalCity}
          </div>
        </div>
        <span className={`badge badge-${booking.status.toLowerCase()}`}>{booking.status}</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', fontSize: '0.88rem', marginBottom: '1rem' }}>
        <div><span style={{ color: 'var(--muted)' }}>Passenger:</span><br />{booking.customerName}</div>
        <div><span style={{ color: 'var(--muted)' }}>Booked:</span><br />{date}</div>
        <div><span style={{ color: 'var(--muted)' }}>Total Cost:</span><br />
          <span style={{ color: 'var(--gold)', fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
            ₹{Number(booking.bookedCost).toLocaleString('en-IN')}
          </span>
        </div>
      </div>

      {booking.status === 'CONFIRMED' && (
        <button
          className="btn btn-danger btn-sm"
          onClick={handleCancel}
          disabled={cancelling}
        >
          {cancelling ? 'Cancelling...' : 'Cancel Booking'}
        </button>
      )}
    </div>
  );
}

export default function MyBookingsPage() {
  const [phone, setPhone]       = useState('');
  const [bookings, setBookings] = useState([]);
  const [searched, setSearched] = useState(false);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');

  const handleSearch = async e => {
    e.preventDefault();
    if (!phone.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await lookupBookings(phone.trim());
      setBookings(res.data);
      setSearched(true);
    } catch {
      setError('Failed to fetch bookings. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async (bookingId) => {
    await cancelBooking(bookingId);
    setBookings(b => b.map(bk =>
      bk.bookingId === bookingId ? { ...bk, status: 'CANCELLED' } : bk
    ));
  };

  return (
    <div style={{ maxWidth: 580, margin: '0 auto' }}>
      <div className="page-header">
        <h1 className="page-title">My <span className="accent">Bookings</span></h1>
        <p className="page-subtitle">Enter your phone number to look up your booking history.</p>
      </div>

      <div className="card" style={{ marginBottom: '2rem' }}>
        <form onSubmit={handleSearch} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-end' }}>
          <div className="form-group" style={{ flex: 1, marginBottom: 0 }}>
            <label className="form-label">Phone Number</label>
            <input
              type="tel"
              className="form-input"
              placeholder="+91 9876543210"
              value={phone}
              onChange={e => setPhone(e.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-primary" disabled={loading || !phone.trim()}>
            {loading ? <><div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Searching</> : 'Search'}
          </button>
        </form>
      </div>

      {error && <div className="alert alert-error">⚠ {error}</div>}

      {searched && (
        <>
          <div className="section-header">
            <h2 className="section-title">Results</h2>
            <span className="section-count">{bookings.length} booking{bookings.length !== 1 ? 's' : ''}</span>
          </div>

          {bookings.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">📭</div>
              <h3>No bookings found</h3>
              <p>No bookings found for <strong>{phone}</strong>. Double-check your number.</p>
            </div>
          ) : (
            bookings.map(b => (
              <BookingCard key={b.bookingId} booking={b} onCancel={handleCancel} />
            ))
          )}
        </>
      )}
    </div>
  );
}
