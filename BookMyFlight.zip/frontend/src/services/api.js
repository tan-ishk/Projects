import axios from 'axios';

const API_BASE = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
});

// ─── Special Deals (Public) ───────────────────────────────────────────────────

export const fetchActiveDeals = () => api.get('/deals');

// ─── Bookings ─────────────────────────────────────────────────────────────────

export const bookFlight = (data) => api.post('/bookings', data);
export const lookupBookings = (phone) => api.get(`/bookings/lookup?phone=${encodeURIComponent(phone)}`);
export const cancelBooking = (id) => api.delete(`/bookings/${id}`);

// ─── Admin ────────────────────────────────────────────────────────────────────

export const adminGetAllDeals = () => api.get('/admin/deals');
export const adminCreateDeal = (data) => api.post('/admin/deals', data);
export const adminUpdateDeal = (id, data) => api.put(`/admin/deals/${id}`, data);
export const adminDeleteDeal = (id) => api.delete(`/admin/deals/${id}`);
export const adminGetAllBookings = () => api.get('/bookings/admin');

export default api;
