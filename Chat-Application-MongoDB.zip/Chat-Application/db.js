/**
 * db.js — MongoDB / Mongoose setup
 *
 * Exports:
 *   connectDB()          — call once at startup; resolves when connected
 *   Message              — Mongoose model for chat messages
 *   Room                 — Mongoose model for rooms
 *
 * The server falls back to the legacy in-memory store gracefully when
 * MONGODB_URI is not set, so existing behaviour is never broken.
 */

const mongoose = require('mongoose');

// ─── Schemas ──────────────────────────────────────────────────────────────────

const messageSchema = new mongoose.Schema(
  {
    type:      { type: String, enum: ['chat', 'system', 'dm'], default: 'chat' },
    room:      { type: String, default: null },   // null for DMs
    from:      { type: String, default: null },
    to:        { type: String, default: null },   // only for DMs
    color:     { type: String, default: null },
    text:      { type: String, default: '' },
    mediaUrl:  { type: String, default: null },
    mediaType: { type: String, default: null },
    mediaName: { type: String, default: null },
    ts:        { type: Number, default: () => Date.now() }
  },
  { versionKey: false }
);

// Index for efficient room-history queries (most-recent-first)
messageSchema.index({ room: 1, ts: -1 });

const roomSchema = new mongoose.Schema(
  {
    name:      { type: String, unique: true, required: true, lowercase: true, trim: true },
    createdAt: { type: Date, default: Date.now }
  },
  { versionKey: false }
);

const Message = mongoose.model('Message', messageSchema);
const Room    = mongoose.model('Room',    roomSchema);

// ─── Connection ───────────────────────────────────────────────────────────────

async function connectDB(uri) {
  if (!uri) {
    console.warn('[db] MONGODB_URI not set — running in memory-only mode.');
    return false;          // signals "DB not available"
  }

  try {
    await mongoose.connect(uri, {
      // recommended options for Mongoose 7+
      serverSelectionTimeoutMS: 5000
    });
    console.log('[db] Connected to MongoDB ✓');
    return true;
  } catch (err) {
    console.error('[db] MongoDB connection failed:', err.message);
    console.warn('[db] Falling back to in-memory mode.');
    return false;
  }
}

module.exports = { connectDB, Message, Room };
