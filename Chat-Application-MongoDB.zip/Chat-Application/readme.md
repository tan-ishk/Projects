# Chat Application

A real-time multi-room chat app built with **Express**, **Socket.IO**, **Pug**, and optional **MongoDB** persistence via **Mongoose**.

---

## Features

- Multi-room chat with live room switching
- Direct (private) messages
- File / image / video sharing
- Troll detection with soothing warnings
- OTP / sensitive-data send confirmation
- Typing indicators
- **MongoDB persistence** — messages and rooms survive server restarts
- **Graceful fallback** — runs fully in-memory if MongoDB is unavailable

---

## Setup

```bash
npm install
```

### Without MongoDB (legacy / in-memory mode)
```bash
npm start
```
Everything works exactly as before. No data is persisted between restarts.

### With MongoDB (Compass / local)

1. Install and start MongoDB locally (default port **27017**).
2. Open **MongoDB Compass** and connect to `mongodb://127.0.0.1:27017/`.
3. Start the server with the env var:

```bash
MONGODB_URI=mongodb://127.0.0.1:27017/chatapp node server.js
# or:
npm run dev
```

The database `chatapp` and collections (`messages`, `rooms`) are created automatically.

### With MongoDB Atlas
```bash
MONGODB_URI="mongodb+srv://<user>:<pass>@cluster.xxxxx.mongodb.net/chatapp" node server.js
```

---

## MongoDB Collections

| Collection | Description |
|---|---|
| `messages` | All chat/system/DM messages. Indexed on `room + ts`. |
| `rooms`    | Persisted room names (survive restarts). |

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `MONGODB_URI` | *(unset)* | Mongo connection string. Omit for memory-only mode. |
| `PORT` | `3000` | HTTP port. |

---

## Viewing data in Compass

1. Connect Compass → `mongodb://127.0.0.1:27017/`
2. Open database **chatapp**
3. Browse **messages** or **rooms**
4. Filter example: `{ room: "general" }` → shows only general-room messages
