/**
 * server.js — Chat Application
 *
 * MongoDB / Mongoose is used when MONGODB_URI env-var is set.
 * If the variable is absent or the connection fails, the app falls back
 * to the original in-memory store — no legacy behaviour is broken.
 *
 * Connect with Compass:  mongodb://127.0.0.1:27017/chatapp
 * Or set env:            MONGODB_URI=mongodb://127.0.0.1:27017/chatapp
 */

const express  = require('express');
const http     = require('http');
const { Server } = require('socket.io');
const path     = require('path');
const multer   = require('multer');
const fs       = require('fs');

const { connectDB, Message, Room } = require('./db');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server);

// ─── Multer ───────────────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, 'public/uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e6);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

// ─── App Config ───────────────────────────────────────────────────────────────
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── DB flag ──────────────────────────────────────────────────────────────────
let dbEnabled = false;

// ─── Legacy In-Memory State ───────────────────────────────────────────────────
const users         = {};
const rooms         = new Set(['general']);
const roomHistory   = {};
const trollWarnings = {};

// ─── Troll Detection (unchanged) ─────────────────────────────────────────────
const TROLL_PATTERNS = [
  /\b(idiot|stupid|dumb|loser|moron|shut up|go away|hate you|worthless)\b/i,
  /\b(kys|kill yourself)\b/i,
  /(!!{3,}|\?{3,})/,
  /[A-Z\s]{10,}/
];
const SOOTHING_RESPONSES = [
  "Hey, let's keep the chat a happy place! Take a breath — we're all here to connect.",
  "Seems like tensions are high! Maybe step away for a moment and come back refreshed ?",
  "This convo is getting heated. Let's cool it down — everyone deserves respect here. ",
  "Disagreements are okay, but let's keep it kind. You're better than this! ",
  "The vibes are off right now — let's reset and chat with empathy, yeah?"
];
function detectTroll(text) { return TROLL_PATTERNS.some(p => p.test(text)); }
function soothingMessage() { return SOOTHING_RESPONSES[Math.floor(Math.random() * SOOTHING_RESPONSES.length)]; }

const PRIVATE_PATTERNS = [
  /\b\d{4,8}\b/,
  /\b(?:\d{4}[- ]?){3}\d{4}\b/,
  /\b\d{3}-\d{2}-\d{4}\b/,
  /password\s*[:=]\s*\S+/i,
  /otp\s*[:=\s]\s*\d{4,}/i
];
function detectPrivate(text) { return PRIVATE_PATTERNS.some(p => p.test(text)); }

// ─── DB Helpers ───────────────────────────────────────────────────────────────
async function dbEnsureRoom(name) {
  if (!dbEnabled) return;
  try { await Room.updateOne({ name }, { $setOnInsert: { name } }, { upsert: true }); }
  catch (e) { console.error('[db] ensureRoom:', e.message); }
}

async function dbSaveMessage(msgObj) {
  if (!dbEnabled) return null;
  try { return await Message.create(msgObj); }
  catch (e) { console.error('[db] saveMessage:', e.message); return null; }
}

async function dbGetRoomHistory(room, limit = 100) {
  if (!dbEnabled) return null;
  try {
    const docs = await Message.find({ room, type: { $in: ['chat', 'system'] } })
      .sort({ ts: -1 }).limit(limit).lean();
    return docs.reverse();
  } catch (e) { console.error('[db] getRoomHistory:', e.message); return null; }
}

async function dbGetAllRooms() {
  if (!dbEnabled) return [];
  try { return (await Room.find({}).lean()).map(d => d.name); }
  catch (e) { console.error('[db] getAllRooms:', e.message); return []; }
}

// ─── Routes ───────────────────────────────────────────────────────────────────
app.get('/',     (req, res) => res.render('login'));
app.get('/chat', (req, res) => res.render('chat', { rooms: [...rooms] }));
app.post('/upload', upload.single('media'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  res.json({ url: '/uploads/' + req.file.filename, name: req.file.originalname, type: req.file.mimetype });
});

// ─── Socket.IO ────────────────────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[connect] ${socket.id}`);

  socket.on('join', async ({ username, room }) => {
    const taken = Object.values(users).find(u => u.username === username);
    if (taken) { socket.emit('join_error', 'Username already taken. Pick another!'); return; }

    const color = `hsl(${Math.floor(Math.random() * 360)}, 65%, 55%)`;
    users[socket.id] = { username, room, color };
    socket.join(room);
    rooms.add(room);
    await dbEnsureRoom(room);

    const dbHistory = await dbGetRoomHistory(room);
    const history   = dbHistory !== null ? dbHistory : (roomHistory[room] || []);
    socket.emit('room_history', history);

    const systemMsg = { type: 'system', text: `${username} joined #${room}`, ts: Date.now() };
    await dbSaveMessage({ ...systemMsg, room });
    if (!roomHistory[room]) roomHistory[room] = [];
    roomHistory[room].push(systemMsg);
    if (roomHistory[room].length > 100) roomHistory[room].shift();

    io.to(room).emit('message', systemMsg);
    broadcastUserList(room);
    socket.emit('joined', { username, room, color, rooms: [...rooms] });
  });

  socket.on('switch_room', async (newRoom) => {
    const user = users[socket.id];
    if (!user) return;
    const oldRoom = user.room;
    socket.leave(oldRoom);
    user.room = newRoom;
    if (!rooms.has(newRoom)) { rooms.add(newRoom); await dbEnsureRoom(newRoom); }
    socket.join(newRoom);

    const leaveMsg = { type: 'system', text: `${user.username} left #${oldRoom}`, ts: Date.now() };
    await dbSaveMessage({ ...leaveMsg, room: oldRoom });
    io.to(oldRoom).emit('message', leaveMsg);
    broadcastUserList(oldRoom);

    const dbHistory = await dbGetRoomHistory(newRoom);
    const history   = dbHistory !== null ? dbHistory : (roomHistory[newRoom] || []);
    socket.emit('room_history', history);

    const joinMsg = { type: 'system', text: `${user.username} joined #${newRoom}`, ts: Date.now() };
    await dbSaveMessage({ ...joinMsg, room: newRoom });
    io.to(newRoom).emit('message', joinMsg);
    broadcastUserList(newRoom);
    socket.emit('room_switched', { room: newRoom });
  });

  socket.on('create_room', async (roomName) => {
    const clean = roomName.trim().toLowerCase().replace(/\s+/g, '-');
    if (!clean) return;
    rooms.add(clean);
    await dbEnsureRoom(clean);
    io.emit('rooms_updated', [...rooms]);
    socket.emit('room_created', clean);
  });

  socket.on('chat_message', async ({ text, mediaUrl, mediaType, mediaName }) => {
    const user = users[socket.id];
    if (!user) return;

    if (text && detectTroll(text)) {
      trollWarnings[socket.id] = (trollWarnings[socket.id] || 0) + 1;
      socket.emit('troll_warning', { soothing: soothingMessage(), count: trollWarnings[socket.id] });
      if (trollWarnings[socket.id] >= 30) {
        socket.emit('message', { type: 'system', text: ' Ebar Besi Barabari hocche', ts: Date.now() });
        return;
      }
    }

    const msg = {
      type: 'chat', from: user.username, color: user.color,
      text, mediaUrl, mediaType, mediaName, room: user.room, ts: Date.now()
    };
    await dbSaveMessage(msg);

    if (!roomHistory[user.room]) roomHistory[user.room] = [];
    roomHistory[user.room].push(msg);
    if (roomHistory[user.room].length > 100) roomHistory[user.room].shift();

    io.to(user.room).emit('message', msg);
  });

  socket.on('private_message', async ({ toUsername, text }) => {
    const sender = users[socket.id];
    if (!sender) return;
    const target = Object.entries(users).find(([, u]) => u.username === toUsername);
    if (!target) { socket.emit('error_msg', `User "${toUsername}" not found or offline.`); return; }
    const [targetId] = target;
    const dm = { type: 'dm', from: sender.username, to: toUsername, color: sender.color, text, ts: Date.now() };
    await dbSaveMessage(dm);
    socket.emit('message', dm);
    io.to(targetId).emit('message', dm);
  });

  socket.on('typing', (isTyping) => {
    const user = users[socket.id];
    if (!user) return;
    socket.to(user.room).emit('user_typing', { username: user.username, isTyping });
  });

  socket.on('disconnect', async () => {
    const user = users[socket.id];
    if (user) {
      const leaveMsg = { type: 'system', text: `${user.username} left the chat`, ts: Date.now() };
      await dbSaveMessage({ ...leaveMsg, room: user.room });
      io.to(user.room).emit('message', leaveMsg);
      delete users[socket.id];
      delete trollWarnings[socket.id];
      broadcastUserList(user.room);
    }
  });

  function broadcastUserList(room) {
    const roomUsers = Object.values(users).filter(u => u.room === room);
    io.to(room).emit('user_list', roomUsers.map(u => ({ username: u.username, color: u.color })));
    io.emit('all_users', Object.values(users).map(u => ({ username: u.username, color: u.color })));
  }
});

// ─── Startup ──────────────────────────────────────────────────────────────────
async function start() {
  dbEnabled = await connectDB(process.env.MONGODB_URI);

  if (dbEnabled) {
    const persistedRooms = await dbGetAllRooms();
    persistedRooms.forEach(r => rooms.add(r));
    await dbEnsureRoom('general');
    console.log(`[db] Loaded ${persistedRooms.length} room(s) from MongoDB.`);
  }

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () =>
    console.log(`Chat server → http://localhost:${PORT}  [DB: ${dbEnabled ? 'MongoDB ✓' : 'memory (fallback)'}]`)
  );
}

start();
